<?php
/**
 * Silence is golden.
 *
 * @package Redux
 */

echo null;
